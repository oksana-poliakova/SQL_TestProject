create materialized view order_ranks_mv as
SELECT orders.user_id,
       orders.product_name,
       orders.quantity,
       rank() OVER (ORDER BY orders.quantity DESC) AS rank
FROM orders;

alter materialized view order_ranks_mv owner to postgres;

