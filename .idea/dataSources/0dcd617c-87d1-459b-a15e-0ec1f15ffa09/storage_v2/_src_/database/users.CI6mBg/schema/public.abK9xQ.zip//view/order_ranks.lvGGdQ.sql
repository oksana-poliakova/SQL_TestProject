create view order_ranks(user_id, product_name, quantity, rank) as
SELECT orders.user_id,
       orders.product_name,
       orders.quantity,
       rank() OVER (ORDER BY orders.quantity DESC) AS rank
FROM orders;

alter table order_ranks
    owner to postgres;

